package ma.est.dao;

import ma.est.model.Emprunt;
import ma.est.util.DatabaseConnection;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class EmpruntDAOImpl implements EmpruntDAO {

    @Override
    public void enregistrerEmprunt(Emprunt emprunt) {
        String sql = "INSERT INTO Emprunt (idLivre, idAdherent, dateEmprunt, dateRetourPrevue, statut) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            pstmt.setInt(1, emprunt.getIdLivre());
            pstmt.setInt(2, emprunt.getIdAdherent());
            pstmt.setDate(3, Date.valueOf(emprunt.getDateEmprunt()));
            pstmt.setDate(4, Date.valueOf(emprunt.getDateRetourPrevue()));
            pstmt.setString(5, emprunt.getStatut());
            pstmt.executeUpdate();
            ResultSet rs = pstmt.getGeneratedKeys();
            if (rs.next()) emprunt.setId(rs.getInt(1));

            // Decrement stock
            String stockSql = "UPDATE Livre SET exemplairesDisponibles = exemplairesDisponibles - 1 WHERE id = ? AND exemplairesDisponibles > 0";
            try (PreparedStatement stockPstmt = conn.prepareStatement(stockSql)) {
                stockPstmt.setInt(1, emprunt.getIdLivre());
                int updated = stockPstmt.executeUpdate();
                if (updated == 0) {
                    throw new SQLException("Pas assez d'exemplaires disponibles");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void retournerEmprunt(int id) {
        String sql = "UPDATE Emprunt SET dateRetourReelle = ?, statut = ? WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            Emprunt e = trouverParId(id);
            if (e == null) return;
            LocalDate retour = LocalDate.now();
            String statut = retour.isAfter(e.getDateRetourPrevue()) ? "Retard" : "Cloture";
            pstmt.setDate(1, Date.valueOf(retour));
            pstmt.setString(2, statut);
            pstmt.setInt(3, id);
            pstmt.executeUpdate();

            // Increment stock
            String stockSql = "UPDATE Livre SET exemplairesDisponibles = exemplairesDisponibles + 1 WHERE id = ?";
            try (PreparedStatement stockPstmt = conn.prepareStatement(stockSql)) {
                stockPstmt.setInt(1, e.getIdLivre());
                stockPstmt.executeUpdate();
            }

            // Block if late >10 days
            long daysLate = java.time.temporal.ChronoUnit.DAYS.between(e.getDateRetourPrevue(), retour);
            if (daysLate > 10) {
                String block = "UPDATE Adherent SET bloque = true WHERE id = ?";
                try (PreparedStatement blockPstmt = conn.prepareStatement(block)) {
                    blockPstmt.setInt(1, e.getIdAdherent());
                    blockPstmt.executeUpdate();
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private Emprunt trouverParId(int id) {
        String sql = "SELECT * FROM Emprunt WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                Emprunt e = new Emprunt();
                e.setId(rs.getInt("id"));
                e.setIdLivre(rs.getInt("idLivre"));
                e.setIdAdherent(rs.getInt("idAdherent"));
                e.setDateEmprunt(rs.getDate("dateEmprunt").toLocalDate());
                e.setDateRetourPrevue(rs.getDate("dateRetourPrevue").toLocalDate());
                e.setDateRetourReelle(rs.getDate("dateRetourReelle") != null ? rs.getDate("dateRetourReelle").toLocalDate() : null);
                e.setStatut(rs.getString("statut"));
                return e;
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return null;
    }

    @Override
    public List<Emprunt> listerTous() {
        List<Emprunt> list = new ArrayList<>();
        String sql = "SELECT * FROM Emprunt";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Emprunt e = new Emprunt();
                e.setId(rs.getInt("id"));
                e.setIdLivre(rs.getInt("idLivre"));
                e.setIdAdherent(rs.getInt("idAdherent"));
                Date dateEmp = rs.getDate("dateEmprunt");
                if (dateEmp != null) e.setDateEmprunt(dateEmp.toLocalDate());
                Date datePrev = rs.getDate("dateRetourPrevue");
                if (datePrev != null) e.setDateRetourPrevue(datePrev.toLocalDate());
                Date dateRet = rs.getDate("dateRetourReelle");
                if (dateRet != null) e.setDateRetourReelle(dateRet.toLocalDate());
                e.setStatut(rs.getString("statut"));
                list.add(e);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public int compterActifsParAdherent(int idAdherent) {
        String sql = "SELECT COUNT(*) FROM Emprunt WHERE idAdherent = ? AND statut = 'Actif'";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, idAdherent);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    @Override
    public List<Emprunt> listerParAdherent(int idAdherent) {
        List<Emprunt> list = new ArrayList<>();
        String sql = "SELECT * FROM Emprunt WHERE idAdherent = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, idAdherent);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                Emprunt e = new Emprunt();
                e.setId(rs.getInt("id"));
                e.setIdLivre(rs.getInt("idLivre"));
                e.setIdAdherent(rs.getInt("idAdherent"));
                Date dateEmp = rs.getDate("dateEmprunt");
                if (dateEmp != null) e.setDateEmprunt(dateEmp.toLocalDate());
                Date datePrev = rs.getDate("dateRetourPrevue");
                if (datePrev != null) e.setDateRetourPrevue(datePrev.toLocalDate());
                Date dateRet = rs.getDate("dateRetourReelle");
                if (dateRet != null) e.setDateRetourReelle(dateRet.toLocalDate());
                e.setStatut(rs.getString("statut"));
                list.add(e);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
}