// LivreDAO.java (interface)
package ma.est.dao;

import ma.est.model.Livre;
import java.util.List;

public interface LivreDAO {
    void ajouter(Livre livre);
    Livre trouverParId(int id);
    void modifier(Livre livre);
    void supprimer(int id);
    List<Livre> listerTous();
}