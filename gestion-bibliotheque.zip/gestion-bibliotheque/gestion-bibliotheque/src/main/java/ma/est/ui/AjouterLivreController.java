package ma.est.ui;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import ma.est.model.Livre;
import ma.est.dao.LivreDAO;
import ma.est.dao.LivreDAOImpl;

public class AjouterLivreController {

    @FXML private TextField isbnField;
    @FXML private TextField titreField;
    @FXML private TextField auteurField;
    @FXML private TextField categorieField;
    @FXML private TextField exemplairesField;

    private DashboardView dashboard;

    public void setDashboard(DashboardView dashboard) {
        this.dashboard = dashboard;
    }

    @FXML
    private void ajouter() {
        try {
            Livre livre = new Livre();
            livre.setIsbn(isbnField.getText().trim());
            livre.setTitre(titreField.getText().trim());
            livre.setAuteur(auteurField.getText().trim());
            livre.setCategorie(categorieField.getText().trim());

            String exText = exemplairesField.getText().trim();
            if (exText.isEmpty() || Integer.parseInt(exText) <= 0) {
                System.out.println("Nombre d'exemplaires invalide");
                return;
            }
            livre.setExemplairesDisponibles(Integer.parseInt(exText));

            LivreDAO dao = new LivreDAOImpl();
            dao.ajouter(livre);

            System.out.println("Livre ajouté avec succès !");

            // Refresh dashboard table
            if (dashboard != null) {
                dashboard.initTables(); // re-init columns (safe)
                dashboard.loadData();   // <-- THIS REFRESHES THE TABLE
            }

            // Close window
            annuler();

        } catch (Exception e) {
            System.out.println("Erreur lors de l'ajout : " + e.getMessage());
            e.printStackTrace();
        }
    }

    @FXML
    private void annuler() {
        ((Stage) isbnField.getScene().getWindow()).close();
    }
}