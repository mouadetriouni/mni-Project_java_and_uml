package ma.est;

import javafx.application.Application;
import javafx.stage.Stage;
import ma.est.ui.LoginView;
import ma.est.util.DatabaseConnection;

public class MainApp extends Application {
    @Override
    public void start(Stage primaryStage) {
        DatabaseConnection.initializeDatabase();
        new LoginView().afficher(primaryStage);
    }

    public static void main(String[] args) {
        launch(args);
    }
}