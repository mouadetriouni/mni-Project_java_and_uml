// AuthService.java
package ma.est.service;

import ma.est.dao.UtilisateurDAO;
import ma.est.dao.UtilisateurDAOImpl;
import ma.est.model.Utilisateur;

public class AuthService {
    private UtilisateurDAO dao = new UtilisateurDAOImpl();

    public Utilisateur login(String username, String password) {
        return dao.authentifier(username, password);
    }
}