package ma.est.dao;

import ma.est.model.Emprunt;
import java.util.List;

public interface EmpruntDAO {
    void enregistrerEmprunt(Emprunt emprunt);
    void retournerEmprunt(int id);
    List<Emprunt> listerTous();
    int compterActifsParAdherent(int idAdherent);
    
    // ADD THIS LINE
    List<Emprunt> listerParAdherent(int idAdherent);
}