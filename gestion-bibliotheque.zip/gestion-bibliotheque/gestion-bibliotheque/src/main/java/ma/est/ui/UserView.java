package ma.est.ui;

import java.time.LocalDate;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import ma.est.model.Emprunt;
import ma.est.model.Livre;
import ma.est.model.Utilisateur;
import ma.est.service.BibliothequeService;

public class UserView {

    @FXML private TableView<Livre> livresTable;
    @FXML private TableView<Emprunt> empruntsTable;

    private BibliothequeService service = new BibliothequeService();
    private Utilisateur currentUser;

    public void setCurrentUser(Utilisateur user) {
        this.currentUser = user;
    }

    public void initAfterLoad() {
        initTables();
        loadData(); // charge les données après les colonnes
    }

    private void initTables() {
        // Catalogue livres
        TableColumn<Livre, String> isbnCol = new TableColumn<>("ISBN");
        isbnCol.setCellValueFactory(new PropertyValueFactory<>("isbn"));
        TableColumn<Livre, String> titreCol = new TableColumn<>("Titre");
        titreCol.setCellValueFactory(new PropertyValueFactory<>("titre"));
        TableColumn<Livre, String> auteurCol = new TableColumn<>("Auteur");
        auteurCol.setCellValueFactory(new PropertyValueFactory<>("auteur"));
        TableColumn<Livre, Integer> exCol = new TableColumn<>("Exemplaires");
        exCol.setCellValueFactory(new PropertyValueFactory<>("exemplairesDisponibles"));

        livresTable.getColumns().setAll(isbnCol, titreCol, auteurCol, exCol);

        // Emprunts de l'utilisateur
        TableColumn<Emprunt, Integer> idCol = new TableColumn<>("ID");
        idCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        TableColumn<Emprunt, Integer> livreCol = new TableColumn<>("ID Livre");
        livreCol.setCellValueFactory(new PropertyValueFactory<>("idLivre"));
        TableColumn<Emprunt, LocalDate> dateEmpCol = new TableColumn<>("Date Emprunt");
        dateEmpCol.setCellValueFactory(new PropertyValueFactory<>("dateEmprunt"));
        TableColumn<Emprunt, LocalDate> datePrevCol = new TableColumn<>("Date Retour Prévue");
        datePrevCol.setCellValueFactory(new PropertyValueFactory<>("dateRetourPrevue"));
        TableColumn<Emprunt, String> statutCol = new TableColumn<>("Statut");
        statutCol.setCellValueFactory(new PropertyValueFactory<>("statut"));

        empruntsTable.getColumns().setAll(idCol, livreCol, dateEmpCol, datePrevCol, statutCol);
    }

    public void loadData() {
        // Toujours charger le catalogue
        livresTable.setItems(FXCollections.observableArrayList(service.listerLivres()));

        // Charger seulement les emprunts de l'utilisateur connecté
        int idAdherent = currentUser.getIdAdherent(); // grâce au lien
        empruntsTable.setItems(FXCollections.observableArrayList(service.listerEmpruntsParAdherent(idAdherent)));
    }

    @FXML
    private void emprunterLivre() {
        Livre selected = livresTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("Veuillez sélectionner un livre dans le catalogue.");
            return;
        }

        int idAdherent = currentUser.getIdAdherent();

        if (idAdherent == 0) {
            showAlert("Erreur : votre compte n'est pas lié à un adhérent.");
            return;
        }

        // Appel au service avec messages dans popup
        try {
            service.emprunterLivre(selected.getId(), idAdherent);
            showAlert("Livre emprunté avec succès !\nRetour prévu le " + LocalDate.now().plusDays(14));
            loadData(); // refresh immédiat
        } catch (IllegalStateException e) {
            showAlert(e.getMessage()); // affiche "Limite de 3 emprunts atteinte" ou "Livre non disponible"
        } catch (Exception e) {
            showAlert("Erreur lors de l'emprunt.");
            e.printStackTrace();
        }
    }

    private void showAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Information");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    @FXML
    private void logout() {
        new LoginView().afficher(new Stage());
        empruntsTable.getScene().getWindow().hide();
    }
}