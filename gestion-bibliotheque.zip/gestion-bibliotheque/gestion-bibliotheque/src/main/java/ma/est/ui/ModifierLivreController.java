package ma.est.ui;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import ma.est.model.Livre;
import ma.est.dao.LivreDAOImpl;

public class ModifierLivreController {

    @FXML private TextField isbnField;
    @FXML private TextField titreField;
    @FXML private TextField auteurField;
    @FXML private TextField categorieField;
    @FXML private TextField exemplairesField;

    private Livre livre;
    private DashboardView dashboard;

    public void setLivre(Livre livre) {
        this.livre = livre;
        // Pré-remplir les champs
        isbnField.setText(livre.getIsbn());
        titreField.setText(livre.getTitre());
        auteurField.setText(livre.getAuteur());
        categorieField.setText(livre.getCategorie());
        exemplairesField.setText(String.valueOf(livre.getExemplairesDisponibles()));
    }

    public void setDashboard(DashboardView dashboard) {
        this.dashboard = dashboard;
    }

    @FXML
    private void modifier() {
        livre.setIsbn(isbnField.getText().trim());
        livre.setTitre(titreField.getText().trim());
        livre.setAuteur(auteurField.getText().trim());
        livre.setCategorie(categorieField.getText().trim());
        livre.setExemplairesDisponibles(Integer.parseInt(exemplairesField.getText().trim()));

        new LivreDAOImpl().modifier(livre);

        if (dashboard != null) {
            dashboard.loadData();
        }

        annuler();
    }

    @FXML
    private void annuler() {
        ((Stage) isbnField.getScene().getWindow()).close();
    }
}