// AdherentDAO.java (interface)
package ma.est.dao;

import ma.est.model.Adherent;
import java.util.List;

public interface AdherentDAO {
    void ajouter(Adherent adherent);
    Adherent trouverParId(int id);
    List<Adherent> listerTous();
}