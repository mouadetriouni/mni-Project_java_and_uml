// UtilisateurDAOImpl.java
package ma.est.dao;

import ma.est.model.Utilisateur;
import ma.est.util.DatabaseConnection;
import org.mindrot.jbcrypt.BCrypt;

import java.sql.*;

public class UtilisateurDAOImpl implements UtilisateurDAO {
    @Override
    public Utilisateur authentifier(String username, String password) {
        String sql = "SELECT * FROM Utilisateur WHERE username = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, username);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                String hashed = rs.getString("password");
                if (BCrypt.checkpw(password, hashed)) {
                    Utilisateur u = new Utilisateur();
                    u.setId(rs.getInt("id"));
                    u.setUsername(rs.getString("username"));
                    u.setPassword(hashed);
                    u.setRole(rs.getString("role"));
                    u.setActif(rs.getBoolean("actif"));
                    u.setIdAdherent(rs.getInt("idAdherent"));
                    return u;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
}