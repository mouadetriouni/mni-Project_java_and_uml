package ma.est.service;

import ma.est.dao.AdherentDAO;
import ma.est.dao.EmpruntDAO;
import ma.est.dao.LivreDAO;
import ma.est.dao.LivreDAOImpl;
import ma.est.dao.AdherentDAOImpl;
import ma.est.dao.EmpruntDAOImpl;
import ma.est.model.Livre;
import ma.est.model.Adherent;
import ma.est.model.Emprunt;

import java.time.LocalDate;
import java.util.List;

public class BibliothequeService {

    private LivreDAO livreDAO = new LivreDAOImpl();
    private AdherentDAO adherentDAO = new AdherentDAOImpl();
    private EmpruntDAO empruntDAO = new EmpruntDAOImpl();

    // List all books
    public List<Livre> listerLivres() {
        return livreDAO.listerTous();
    }

    // List all members
    public List<Adherent> listerAdherents() {
        return adherentDAO.listerTous();
    }

    // List all loans
    public List<Emprunt> listerEmprunts() {
        return empruntDAO.listerTous();
    }

    // NEW: List loans for a specific adherent (used for USER role)
    public List<Emprunt> listerEmpruntsParAdherent(int idAdherent) {
        return empruntDAO.listerParAdherent(idAdherent);
    }

    // Borrow a book
    public void emprunterLivre(int idLivre, int idAdherent) {
        Livre livre = livreDAO.trouverParId(idLivre);
        if (livre == null) {
            throw new IllegalStateException("Livre introuvable.");
        }
        if (livre.getExemplairesDisponibles() <= 0) {
            throw new IllegalStateException("Livre non disponible (plus d'exemplaires).");
        }
        if (empruntDAO.compterActifsParAdherent(idAdherent) >= 3) {
            throw new IllegalStateException("Limite de 3 emprunts atteinte.");
        }

        Emprunt emprunt = new Emprunt();
        emprunt.setIdLivre(idLivre);
        emprunt.setIdAdherent(idAdherent);
        emprunt.setDateEmprunt(LocalDate.now());
        emprunt.setDateRetourPrevue(LocalDate.now().plusDays(14));
        emprunt.setStatut("Actif");

        empruntDAO.enregistrerEmprunt(emprunt);
    }

    public void supprimerLivre(int id) {
        livreDAO.supprimer(id);
    }

    public void retournerEmprunt(int id) {
        empruntDAO.retournerEmprunt(id);
    }
}