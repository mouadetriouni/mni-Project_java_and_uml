package ma.est;

import org.junit.jupiter.api.Test;

public class AppTest {
    @Test
    void testApp() {}
}
