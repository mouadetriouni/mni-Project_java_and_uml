// UtilisateurDAO.java (interface)
package ma.est.dao;

import ma.est.model.Utilisateur;

public interface UtilisateurDAO {
    Utilisateur authentifier(String username, String password);
}