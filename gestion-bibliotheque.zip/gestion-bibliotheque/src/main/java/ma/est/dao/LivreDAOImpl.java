package ma.est.dao;

import ma.est.model.Livre;
import ma.est.util.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class LivreDAOImpl implements LivreDAO {

    @Override
    public void ajouter(Livre livre) {
        String sql = "INSERT INTO Livre (isbn, titre, auteur, categorie, exemplairesDisponibles) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            pstmt.setString(1, livre.getIsbn());
            pstmt.setString(2, livre.getTitre());
            pstmt.setString(3, livre.getAuteur());
            pstmt.setString(4, livre.getCategorie());
            pstmt.setInt(5, livre.getExemplairesDisponibles());
            int rows = pstmt.executeUpdate();
            System.out.println("Rows inserted: " + rows);
            if (rows > 0) {
                ResultSet rs = pstmt.getGeneratedKeys();
                if (rs.next()) {
                    livre.setId(rs.getInt(1));
                }
            }
        } catch (SQLException e) {
            System.out.println("ERROR INSERTING BOOK:");
            e.printStackTrace();
        }
    }

    @Override
    public void modifier(Livre livre) {
        String sql = "UPDATE Livre SET isbn = ?, titre = ?, auteur = ?, categorie = ?, exemplairesDisponibles = ? WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, livre.getIsbn());
            pstmt.setString(2, livre.getTitre());
            pstmt.setString(3, livre.getAuteur());
            pstmt.setString(4, livre.getCategorie());
            pstmt.setInt(5, livre.getExemplairesDisponibles());
            pstmt.setInt(6, livre.getId());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public Livre trouverParId(int id) {
        String sql = "SELECT * FROM Livre WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                Livre livre = new Livre();
                livre.setId(rs.getInt("id"));
                livre.setIsbn(rs.getString("isbn"));
                livre.setTitre(rs.getString("titre"));
                livre.setAuteur(rs.getString("auteur"));
                livre.setCategorie(rs.getString("categorie"));
                livre.setExemplairesDisponibles(rs.getInt("exemplairesDisponibles"));
                return livre;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public void supprimer(int id) {
        String sql = "DELETE FROM Livre WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public List<Livre> listerTous() {
        List<Livre> list = new ArrayList<>();
        String sql = "SELECT * FROM Livre";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Livre l = new Livre();
                l.setId(rs.getInt("id"));
                l.setIsbn(rs.getString("isbn"));
                l.setTitre(rs.getString("titre"));
                l.setAuteur(rs.getString("auteur"));
                l.setCategorie(rs.getString("categorie"));
                l.setExemplairesDisponibles(rs.getInt("exemplairesDisponibles"));
                list.add(l);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
}