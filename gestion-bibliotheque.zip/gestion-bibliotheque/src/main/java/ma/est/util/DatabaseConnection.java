package ma.est.util;

import org.mindrot.jbcrypt.BCrypt;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;          // ← ADD THIS
import java.sql.PreparedStatement;   // ← ADD THIS
import java.util.Properties;

public class DatabaseConnection {
    private static Properties props = new Properties();

    static {
        try (InputStream is = DatabaseConnection.class.getResourceAsStream("/application.properties")) {
            props.load(is);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(
            props.getProperty("db.url"),
            props.getProperty("db.user"),
            props.getProperty("db.password")
        );
    }

    public static void initializeDatabase() {
        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement()) {

            String sqlLivre = "CREATE TABLE IF NOT EXISTS Livre (" +
                    "id INT AUTO_INCREMENT PRIMARY KEY, " +
                    "isbn VARCHAR(20) UNIQUE, " +
                    "titre VARCHAR(100), " +
                    "auteur VARCHAR(100), " +
                    "categorie VARCHAR(50), " +
                    "exemplairesDisponibles INT)";
            stmt.execute(sqlLivre);

            String sqlAdherent = "CREATE TABLE IF NOT EXISTS Adherent (" +
                    "id INT AUTO_INCREMENT PRIMARY KEY, " +
                    "nom VARCHAR(100), " +
                    "email VARCHAR(100) UNIQUE, " +
                    "bloque BOOLEAN DEFAULT FALSE)";
            stmt.execute(sqlAdherent);

            String sqlEmprunt = "CREATE TABLE IF NOT EXISTS Emprunt (" +
                    "id INT AUTO_INCREMENT PRIMARY KEY, " +
                    "idLivre INT, " +
                    "idAdherent INT, " +
                    "dateEmprunt DATE, " +
                    "dateRetourPrevue DATE, " +
                    "dateRetourReelle DATE, " +
                    "statut VARCHAR(20), " +
                    "FOREIGN KEY (idLivre) REFERENCES Livre(id) ON DELETE CASCADE, " +
                    "FOREIGN KEY (idAdherent) REFERENCES Adherent(id) ON DELETE CASCADE)";
            stmt.execute(sqlEmprunt);

            String sqlUtilisateur = "CREATE TABLE IF NOT EXISTS Utilisateur (" +
                    "id INT AUTO_INCREMENT PRIMARY KEY, " +
                    "username VARCHAR(50) UNIQUE, " +
                    "password VARCHAR(255), " +
                    "role VARCHAR(10), " +
                    "actif BOOLEAN DEFAULT TRUE)";
            stmt.execute(sqlUtilisateur);

            // Default admin
            String hashed = BCrypt.hashpw("admin", BCrypt.gensalt());
            String sqlAdmin = "INSERT IGNORE INTO Utilisateur (username, password, role) " +
                              "VALUES ('admin', '" + hashed + "', 'ADMIN')";
            stmt.executeUpdate(sqlAdmin);

            // Créer un utilisateur USER (appel unique)
            creerUtilisateurTest();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void creerUtilisateurTest() {
        // Liste des utilisateurs à créer
        String[][] users = {
            {"oussama06", "oussama123", "Oussama", "oussama06@example.com"},
            {"oussama01", "oussama123", "Oussama01", "oussama01@example.com"},
            {"test1", "test123", "Test1", "test1@example.com"},
            {"test2", "test123", "Test2", "test2@example.com"}
        };

        try (Connection conn = getConnection()) {
            conn.setAutoCommit(false);

            for (String[] user : users) {
                String username = user[0];
                String plainPassword = user[1];
                String nom = user[2];
                String email = user[3];

                // Vérifie si l'utilisateur existe déjà
                String checkUser = "SELECT COUNT(*) FROM Utilisateur WHERE username = ?";
                try (PreparedStatement psCheck = conn.prepareStatement(checkUser)) {
                    psCheck.setString(1, username);
                    ResultSet rs = psCheck.executeQuery();
                    rs.next();
                    if (rs.getInt(1) > 0) {
                        System.out.println("Utilisateur " + username + " déjà existant");
                        continue;
                    }
                }

                // Crée l'adhérent
                String sqlAdh = "INSERT IGNORE INTO Adherent (nom, email, bloque) VALUES (?, ?, false)";
                int idAdherent;
                try (PreparedStatement psAdh = conn.prepareStatement(sqlAdh, Statement.RETURN_GENERATED_KEYS)) {
                    psAdh.setString(1, nom);
                    psAdh.setString(2, email);
                    psAdh.executeUpdate();
                    ResultSet rsAdh = psAdh.getGeneratedKeys();
                    if (rsAdh.next()) {
                        idAdherent = rsAdh.getInt(1);
                    } else {
                        // Récupère l'ID si déjà existant
                        String getId = "SELECT id FROM Adherent WHERE email = ?";
                        try (PreparedStatement psGet = conn.prepareStatement(getId)) {
                            psGet.setString(1, email);
                            ResultSet rsGet = psGet.executeQuery();
                            rsGet.next();
                            idAdherent = rsGet.getInt("id");
                        }
                    }
                }

                // Génère hash valide
                String hashed = BCrypt.hashpw(plainPassword, BCrypt.gensalt());

                // Crée l'utilisateur
                String sqlUser = "INSERT INTO Utilisateur (username, password, role, actif, idAdherent) VALUES (?, ?, 'USER', TRUE, ?)";
                try (PreparedStatement psUser = conn.prepareStatement(sqlUser)) {
                    psUser.setString(1, username);
                    psUser.setString(2, hashed);
                    psUser.setInt(3, idAdherent);
                    psUser.executeUpdate();
                }

                System.out.println("Utilisateur créé : " + username + " / " + plainPassword + " (adhérent ID: " + idAdherent + ")");
            }

            conn.commit();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}