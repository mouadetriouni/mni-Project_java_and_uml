package ma.est.ui;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import ma.est.model.Adherent;
import ma.est.model.Emprunt;
import ma.est.model.Livre;
import ma.est.model.Utilisateur;
import ma.est.service.BibliothequeService;

import java.io.IOException;

public class DashboardView {

    @FXML private TabPane tabPane;
    @FXML private Tab livresTab;
    @FXML private Tab adherentsTab;
    @FXML private Tab empruntsTab;
    @FXML private TableView<Livre> livresTable;
    @FXML private TableView<Adherent> adherentsTable;
    @FXML private TableView<Emprunt> empruntsTable;

    private BibliothequeService service = new BibliothequeService();
    private Utilisateur currentUser;
    private String role;

    public DashboardView() {
    }

    public void setCurrentUser(Utilisateur user) {
        this.currentUser = user;
        this.role = user.getRole();
    }

    public void setRole(String role) {
        this.role = role;
    }

    public void initAfterLoad() {
        initTables();
        loadData();

        if ("USER".equals(role)) {
            livresTab.setDisable(true);
            adherentsTab.setDisable(true);
        }
    }

    public void initTables() {
        // Livres
        TableColumn<Livre, String> isbnCol = new TableColumn<>("ISBN");
        isbnCol.setCellValueFactory(new PropertyValueFactory<>("isbn"));
        TableColumn<Livre, String> titreCol = new TableColumn<>("Titre");
        titreCol.setCellValueFactory(new PropertyValueFactory<>("titre"));
        TableColumn<Livre, String> auteurCol = new TableColumn<>("Auteur");
        auteurCol.setCellValueFactory(new PropertyValueFactory<>("auteur"));
        TableColumn<Livre, String> catCol = new TableColumn<>("Catégorie");
        catCol.setCellValueFactory(new PropertyValueFactory<>("categorie"));
        TableColumn<Livre, Integer> exCol = new TableColumn<>("Exemplaires");
        exCol.setCellValueFactory(new PropertyValueFactory<>("exemplairesDisponibles"));

        livresTable.getColumns().setAll(isbnCol, titreCol, auteurCol, catCol, exCol);

        // Adhérents
        TableColumn<Adherent, Integer> idAdhCol = new TableColumn<>("ID");
        idAdhCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        TableColumn<Adherent, String> nomCol = new TableColumn<>("Nom");
        nomCol.setCellValueFactory(new PropertyValueFactory<>("nom"));
        TableColumn<Adherent, String> emailCol = new TableColumn<>("Email");
        emailCol.setCellValueFactory(new PropertyValueFactory<>("email"));
        TableColumn<Adherent, Boolean> bloqueCol = new TableColumn<>("Bloqué");
        bloqueCol.setCellValueFactory(new PropertyValueFactory<>("bloque"));

        adherentsTable.getColumns().setAll(idAdhCol, nomCol, emailCol, bloqueCol);

        // Emprunts
        TableColumn<Emprunt, Integer> idEmpCol = new TableColumn<>("ID");
        idEmpCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        TableColumn<Emprunt, Integer> livreIdCol = new TableColumn<>("ID Livre");
        livreIdCol.setCellValueFactory(new PropertyValueFactory<>("idLivre"));
        TableColumn<Emprunt, Integer> adhIdCol = new TableColumn<>("ID Adhérent");
        adhIdCol.setCellValueFactory(new PropertyValueFactory<>("idAdherent"));
        TableColumn<Emprunt, String> dateEmpCol = new TableColumn<>("Date Emprunt");
        dateEmpCol.setCellValueFactory(new PropertyValueFactory<>("dateEmprunt"));
        TableColumn<Emprunt, String> datePrevCol = new TableColumn<>("Date Retour Prévue");
        datePrevCol.setCellValueFactory(new PropertyValueFactory<>("dateRetourPrevue"));
        TableColumn<Emprunt, String> statutCol = new TableColumn<>("Statut");
        statutCol.setCellValueFactory(new PropertyValueFactory<>("statut"));

        empruntsTable.getColumns().setAll(idEmpCol, livreIdCol, adhIdCol, dateEmpCol, datePrevCol, statutCol);
    }

    public void loadData() {
        livresTable.setItems(FXCollections.observableArrayList(service.listerLivres()));
        adherentsTable.setItems(FXCollections.observableArrayList(service.listerAdherents()));
        empruntsTable.setItems(FXCollections.observableArrayList(service.listerEmprunts()));
    }

    @FXML
    private void ajouterLivre() {
        if (!"ADMIN".equals(role)) return;

        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/AjouterLivre.fxml"));
            Parent root = loader.load();
            AjouterLivreController controller = loader.getController();
            controller.setDashboard(this);
            Stage stage = new Stage();
            stage.setTitle("Ajouter un livre");
            stage.setScene(new Scene(root, 400, 400));
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void supprimerLivre() {
        if (!"ADMIN".equals(role)) return;

        Livre selected = livresTable.getSelectionModel().getSelectedItem();
        if (selected != null) {
            service.supprimerLivre(selected.getId());
            loadData();
        }
    }
    @FXML
    private void modifierLivre() {
        if (!"ADMIN".equals(role)) return;

        Livre selected = livresTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            System.out.println("Sélectionnez un livre à modifier");
            return;
        }

        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/ModifierLivre.fxml"));
            Parent root = loader.load();

            ModifierLivreController controller = loader.getController();
            controller.setLivre(selected);
            controller.setDashboard(this);

            Stage stage = new Stage();
            stage.setTitle("Modifier un livre");
            stage.setScene(new Scene(root, 400, 400));
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void logout() {
        new LoginView().afficher(new Stage());
        tabPane.getScene().getWindow().hide();
    }
}