package ma.est.ui;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import ma.est.model.Utilisateur;
import ma.est.service.AuthService;

import java.io.IOException;

public class LoginView {
    @FXML private TextField usernameField;
    @FXML private PasswordField passwordField;

    private AuthService authService = new AuthService();

    public void afficher(Stage stage) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/Login.fxml"));
            Parent root = loader.load();
            stage.setTitle("Connexion");
            stage.setScene(new Scene(root, 400, 300));
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void login() {
        String user = usernameField.getText();
        String pass = passwordField.getText();
        Utilisateur u = authService.login(user, pass);
        if (u != null && u.isActif()) {
            try {
                Parent root;
                FXMLLoader loader;

                if ("ADMIN".equals(u.getRole())) {
                    loader = new FXMLLoader(getClass().getResource("/Dashboard.fxml"));
                    root = loader.load();
                    DashboardView controller = loader.getController();
                    controller.setCurrentUser(u);
                    controller.initAfterLoad();
                } else {
                    loader = new FXMLLoader(getClass().getResource("/UserView.fxml"));
                    root = loader.load();
                    UserView controller = loader.getController();
                    controller.setCurrentUser(u);
                    controller.initAfterLoad();
                }

                Stage stage = new Stage();
                stage.setTitle("Bibliothèque");
                stage.setScene(new Scene(root, 800, 600));
                stage.show();

                usernameField.getScene().getWindow().hide();
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            System.out.println("Échec de connexion");
        }
    }
}